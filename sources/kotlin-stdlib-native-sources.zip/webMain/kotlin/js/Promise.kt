/*
 * Copyright 2010-2022 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package kotlin.js

import kotlin.internal.LowPriorityInOverloadResolution

/**
 * Exposes the JavaScript [Promise object](https://developer.mozilla.org/en/docs/Web/JavaScript/Reference/Global_Objects/Promise) to Kotlin.
 */
@ExperimentalWasmJsInterop
@SinceKotlin("2.2")
public expect class Promise<out T : JsAny?>(executor: (resolve: (T) -> Unit, reject: (JsPromiseError) -> Unit) -> Unit): JsAny {
    @LowPriorityInOverloadResolution
    public fun <S : JsAny?> then(onFulfilled: ((T) -> S)?): Promise<S>

    @LowPriorityInOverloadResolution
    public fun <S : JsAny?> then(onFulfilled: ((T) -> S)?, onRejected: ((JsPromiseError) -> S)?): Promise<S>

    public fun <S : JsAny?> catch(onRejected: (JsPromiseError) -> S): Promise<S>
    public fun finally(onFinally: () -> Unit): Promise<T>

    public companion object {
        public fun <S : JsAny?> all(promise: JsArray<out Promise<S>>): Promise<JsArray<out S>>
        public fun <S : JsAny?> race(promise: JsArray<out Promise<S>>): Promise<S>
        public fun reject(e: JsPromiseError): Promise<Nothing>
        public fun <S : JsAny?> resolve(e: S): Promise<S>
        public fun <S : JsAny?> resolve(e: Promise<S>): Promise<S>
    }
}